from masterFitter import masterFitter 

# 'method' is a function that is present in a file called 'file.py'