from cantera.build.python import cantera 

# 'method' is a function that is present in a file called 'file.py'