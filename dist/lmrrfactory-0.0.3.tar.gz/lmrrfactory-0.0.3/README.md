# LMRR-generator
Automatically generates LMR-R reactions (and mechanisms) according to the user’s choice of Plog, Troe, or Chebyshev sub-formats
