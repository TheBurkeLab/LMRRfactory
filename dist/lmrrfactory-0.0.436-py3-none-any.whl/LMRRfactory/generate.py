import yaml
import numpy as np
from scipy.optimize import least_squares
from scipy.optimize import curve_fit
import copy
from collections import Counter
import re
import os
from importlib.resources import files
import cantera as ct
import warnings
import io

warnings.filterwarnings("ignore")

class makeYAML:
    def __init__(self,mechInput=None, colliderInput=None, lmrrInput=None,outputPath=".",allPdep=False):
        self.T_ls = None
        self.P_ls = None
        self.n_P= None
        self.n_T= None
        self.P_min = None
        self.P_max = None
        self.T_min = None
        self.T_max = None
        self.rxnIdx = None
        self.colliderInput=None
        self.units = self._loadYAML(mechInput).get("units",{})
        # self.allPdep is option to apply generic 3b-effs to all p-dep reactions in mechanism that haven't already been explicitly specified in either "thirdbodydefaults.yaml" or self.colliderInput
        self.allPdep = False
        os.makedirs(outputPath,exist_ok=True)
        path=outputPath+'/'

        if mechInput:
            if colliderInput:
                self.colliderInput = colliderInput
            self.mechInput = mechInput
            
            self.foutName = os.path.basename(self.mechInput).replace(".yaml","")
            self.foutName = path + self.foutName + "_LMRR"
            if allPdep:
                self.allPdep = True
                self.foutName = self.foutName + "_allP"
            self.data = self._generateYAML()
        if lmrrInput:
            try:
                with open(lmrrInput) as f:
                    self.data = yaml.safe_load(f)
                self.foutName = path + lmrrInput.replace(".yaml","")
            except FileNotFoundError:
                print(f"Error: The file '{lmrrInput}' was not found.")

    def _generateYAML(self):
        # data_path = pkg_resources.resource_filename('LMRRfactory', '/')
        data_path = str(files("LMRRfactory"))
        mech_obj = ct.Solution(self.mechInput)
        self._lookForPdep(mech_obj) # Verify that 'mech' has >=1 relevant p-dep reaction
        data = {
            'mech_obj': mech_obj,
            'mech_pes': self._getPES(mech_obj),
            'defaults': self._loadYAML(data_path+'/'+"thirdbodydefaults.yaml"),
            'input': self._loadYAML(self.colliderInput) if self.colliderInput is not None else None,
            'allPdep': self.allPdep, # True or False
        }
        # normalize species as uppercase
        self._normalizedKeys(data)

        # yml = self.loadYAML(self.mechInput)
        # data['extras'] = [yml[]]
        # Remove defaults colliders and reactions that were explictly provided by user
        self._deleteDuplicates(data)
        # Blend the user inputs and remaining collider defaults into a single YAML
        self._blendedInput(data)
        # Sub the colliders into their corresponding reactions in the input mechanism
        self._zippedMech(data)
        # self.validate(data['output'])
        self._saveYAML(data['output'], self.foutName+".yaml")
        print(f"LMR-R mechanism successfully generated and stored at "
            f"{self.foutName}.yaml")
        return data['output']

    def _normalizedKeys(self,data):
        def capitalize(dict):
            return {k.capitalize(): v for k, v in dict.items()}
        for defaultRxn in data['defaults']['reactions']:
            for col in defaultRxn['colliders']:
                col['composition'] = capitalize(col['composition'])
            defaultRxn['reference-collider'] = defaultRxn['reference-collider'].upper()
            defaultRxn['pes'] = capitalize(defaultRxn['pes'])
        if data.get('input') is not None and data['input'].get('reactions') is not None:
            for inputRxn in data['input']['reactions']:
                for col in inputRxn['colliders']:
                    col['composition'] = capitalize(col['composition'])
                inputRxn['reference-collider'] = inputRxn['reference-collider'].upper()
                inputRxn['pes'] = capitalize(inputRxn['pes'])
        sp_dict = {}
        for sp in data['mech_obj'].species():
            sp_dict[sp.name.upper()] = dict(sp.composition.items())
        data['species_dict']=sp_dict

    def _lookForPdep(self, gas):
        if not any(
            reaction.reaction_type in ['falloff-Troe','pressure-dependent-Arrhenius', 'Chebyshev', 'three-body-linear-Burke']
            for reaction in gas.reactions()
        ):
            raise ValueError("No pressure-dependent reactions found in mechanism."
                            " Please choose another mechanism.")
    
    def _getPES(self,gas): #must input an equation that has already been normalized
        pes=[]
        for reaction in gas.reactions():
            compositions = []
            reactant_species = list(reaction.reactants.keys())
            reactant_coeffs = list(reaction.reactants.values())
            for i, reactant in enumerate(reactant_species):
                spec = gas.species(reactant)
                c = spec.composition
                c_scaled = {k.upper(): v*reactant_coeffs[i] for k, v in c.items()}
                compositions.append(c_scaled)
            counters = [Counter(comp) for comp in compositions]
            pes.append(sum(counters, Counter()))
        return pes

    def _deleteDuplicates(self, data): # delete duplicates from thirdBodyDefaults
        newData = {'generic-colliders': data['defaults']['generic-colliders'],
                'reactions': []}
        inputRxnNames = None
        if data.get('input') is not None:
            if data['input'].get('reactions') is not None:
                inputRxnNames = [rxn['pes'] for rxn in data['input']['reactions']]
                inputColliderNames = [[col['composition'] for col in rxn['colliders']]
                                    for rxn in data['input']['reactions']]
        for defaultRxn in data['defaults']['reactions']:
            if inputRxnNames is not None and defaultRxn['pes'] in inputRxnNames:
                idx = inputRxnNames.index(defaultRxn['pes'])
                inputColliders = inputColliderNames[idx]
                newColliderList = [col for col in defaultRxn['colliders']
                                if col['composition'] not in inputColliders]
                if len(newColliderList)>0:
                    newData['reactions'].append({
                        'name': defaultRxn['name'],
                        'pes': defaultRxn['pes'],
                        'reference-collider': defaultRxn['reference-collider'],
                        'colliders': newColliderList
                    })
            else: # reaction isn't in input, so keep the entire default rxn
                newData['reactions'].append(defaultRxn)
        data['defaults']=newData

    

    def _blendedInput(self, data):
        blendData = {'reactions': []}
        
        # first fill it with all of the default reactions and colliders (which have valid species)
        for defaultRxn in data['defaults']['reactions']:
            newCollList = []
            for col in defaultRxn['colliders']:
                if col['composition'] in list(data['species_dict'].values()):
                    newCollList.append(col)
            defaultRxn['colliders'] = newCollList
            blendData['reactions'].append(defaultRxn)
        defaultRxnNames = [rxn['pes'] for rxn in blendData['reactions']]
        if data.get('input') is not None:
            if data['input'].get('reactions') is not None:
                for inputRxn in data['input']['reactions']:
                    # Check if input reaction also exists in defaults file, otherwise add the entire input reaction to the blend as-is
                    if inputRxn['pes'] in defaultRxnNames:
                        idx = defaultRxnNames.index(inputRxn['pes'])
                        blendRxn = blendData['reactions'][idx]
                        # If reference colliders match, append new colliders, otherwise override with the user inputs
                        if inputRxn['reference-collider'] == blendRxn['reference-collider']:
                            newColliders = [col for col in inputRxn['colliders']
                                            if col['composition'] in list(data['species_dict'].values())]
                            blendRxn['colliders'].extend(newColliders)
                        else:
                            print(f"User-provided reference collider for {inputRxn['equation']}, "
                                f"({inputRxn['reference-collider']}) does not match the program "
                                f"default ({blendData['reactions'][idx]['reference-collider']})."
                                f"\nThe default colliders have thus been deleted and the reaction"
                                f" has been completely overrided by (rather than blended with) "
                                f"the user's custom input values.")
                            blendRxn['reference-collider'] = inputRxn['reference-collider']
                            newColliders = [col for col in inputRxn['colliders']
                                            if col['composition'] in list(data['species_dict'].values())]
                            blendRxn['colliders'] = newColliders
                            # blendRxn['colliders'] = inputRxn['colliders']
                    else:
                        if all(col['composition'] in list(data['species_dict'].values()) for col in inputRxn['colliders']):
                            blendData['reactions'].append(inputRxn)
        data['blend']=blendData
    
    def _arrheniusFit(self, col):
        newCol = copy.deepcopy(col)
        temps=np.array(newCol['temperatures'])
        eps = np.array(newCol['efficiency'])
        if len(temps) == 3 and len(eps) == 3:
            def arrhenius_rate(T, A, beta, Ea):
                return np.log(A) + beta*np.log(T)+ (-Ea/(ct.gas_constant*T))
            popt, pcov = curve_fit(arrhenius_rate, temps, np.log(eps),maxfev = 3000000)
            fits = [popt[0],popt[1],popt[2]]
        elif len(temps) == 2 and len (eps) == 2:
            def arrhenius_rate(T, A, beta):
                return np.log(A) + beta*np.log(T)
            popt, pcov = curve_fit(arrhenius_rate, temps, np.log(eps),maxfev = 3000000)
            fits = [popt[0],popt[1],0.0]
        fits = [float(fit) for fit in fits]
        newCol['efficiency'] = {'A': fits[0],'b': fits[1],'Ea': fits[2]}
        newCol.pop('temperatures', None)
        newCol.pop('composition')
        return dict(newCol)

    def _colliders(self,data,mech_rxn,blend_rxn=None,generic=False):
        divisor = 1
        colliders=[]
        colliderNames=[]
        is_M_N2 = False
        troe_efficiencies={}
        # print(mech_rxn.input_data['equation'])
        
        if mech_rxn.reaction_type == 'falloff-Troe':
            troe_efficiencies= mech_rxn.input_data.get('efficiencies', {})
            # for sp_name in list(troe_efficiencies_raw.keys()):
            #     # [disregard] make the keys the compositions instead of species names
            #     troe_efficiencies[sp_name] = troe_efficiencies_raw[sp_name]
        elif mech_rxn.reaction_type == 'three-body-linear-Burke': #case where we've used the linear Burke format so that Troe params can be used alongside a PLOG 
            # for c, col in enumerate(mech_rxn.input_data.get('colliders', {})):
            #     if col['name'].upper() == 'AR':

            for c, col in enumerate(mech_rxn.input_data.get('colliders', {})):
                if c>0 and col['efficiency']['b']==0 and col['efficiency']['Ea']==0:

                    troe_efficiencies[col['name']]=col['efficiency']['A'] ## WHY ARE WE USING TROE EFFICIENCIES HERE
        
        for name, val in troe_efficiencies.items():
            comp = data['species_dict'][name]
            # comp = self._normalizedKeys(data['species_dict'][name])
            # comp = {k.upper(): v for k, v in data['species_dict'][name].items()}
            # Check if N2 is the reference collider instead of Ar
            if comp=={'Ar': 1} and val!=0 and val !=1:
                is_M_N2 = True
                divisor = 1/val #ratio of N2:Ar
            if comp=={'Ar': 1} and val==0 :
                is_M_N2 = True
                divisor = 1 #imperfect solution, doesn't scale colliders, i.e. 1/val, to avoid dividing by zero but still acknowledges that rxn is w.r.t. N2

            # Give warning if both Ar and N2 are non-unity colliders
            if is_M_N2 and comp=={'N': 2} and val!=0 and val !=1:
                print(f"Warning: {mech_rxn} has both Ar and N2 as non-unity colliders!")
        if is_M_N2:
            if blend_rxn:
                divisors=[]
                # Extract T-dependent values for N2 if blend_rxn is provided
                for col in blend_rxn['colliders']:
                    
                    if col['composition']=={'N': 2}:
                        divisors.extend(col['efficiency']) #T-dep divisor of length 2 or 39p^;
                # Make reaction-specific colliders wrt N2 and append to collider list 
                for col in blend_rxn['colliders']:
                    #Convert N2:Ar database entry to Ar:N2
                    if col['composition']=={'N': 2}:
                        col['composition']={'Ar': 1}
                        col['name']=next(k for k, v in data['species_dict'].items() if v == col['composition'])
                        col['efficiency']=np.divide(1,col['efficiency'])
                        colliders.append(self._arrheniusFit(col))
                        colliderNames.append(col['composition'])
                    elif col['composition'] in list(data['species_dict'].values()):
                        for i in range(len(divisors)):
                            try:
                                col['efficiency'] = np.divide(col['efficiency'], divisors[i])
                                break
                            except:
                                pass
                        colliders.append(self._arrheniusFit(col))
                        colliderNames.append(col['composition'])
                # print(divisors)
            # colliderNames=set(colliderNames)
            # Add troe efficiencies that haven't already been given a value
            for name, val in troe_efficiencies.items():
                comp = data['species_dict'][name]
                already_given = comp in colliderNames
                if not already_given and not comp=={'N': 2}: #ignores the redundant n2=1 entry
                    colliders.append({
                        'name': next(k for k, v in data['species_dict'].items() if v == comp),
                        'efficiency': {'A':val,'b':0,'Ea':0 },
                        'note': 'present work',
                    })
                    colliderNames.append(data['species_dict'][name])
            if generic:
                for col in data['defaults']['generic-colliders']:
                    already_given = col['composition'] in colliderNames
                    if col['composition'] in list(data['species_dict'].keys()) and not already_given and not col['composition']=={'N': 2}:
                        if col.get('temperatures') is not None:
                            col['efficiency'] = np.divide(col['efficiency'],divisor)
                            colliders.append(self._arrheniusFit(col))
                        else:
                            colliders.append({
                                'name': next(k for k, v in data['species_dict'].items() if v == col['composition']),
                                'efficiency': {'A': col['efficiency']/divisor,'b':0,'Ea':0},
                                'note': col['note']
                            })
        else:
            if blend_rxn:
                # Make reaction-specific colliders wrt Ar and append to collider list 
                for col in blend_rxn['colliders']:
                    if col['composition'] in list(data['species_dict'].values()):
                        colliders.append(self._arrheniusFit(col))
                        colliderNames.append(col['composition'])
            # Add troe efficiencies that haven't already been given a value
            for name, val in troe_efficiencies.items():
                comp = data['species_dict'][name]
                # already_given = any(col['name'] == name for col in colliders)
                already_given = comp in colliderNames
                if not already_given and not comp=={'Ar': 1}:
                    colliders.append({
                        'name': next(k for k, v in data['species_dict'].items() if v == comp),
                        'efficiency': {'A':val,'b':0,'Ea':0 },
                        'note': 'present work',
                    })
                    colliderNames.append(comp)
            if generic:
                for col in data['defaults']['generic-colliders']:
                    already_given = col['composition'] in colliderNames
                    if col['composition'] in list(data['species_dict'].values()) and not already_given and not col['composition']=={'Ar': 1}:
                        if col.get('temperatures') is not None:
                            colliders.append(self._arrheniusFit(col))
                        else:
                            colliders.append({
                                'name': next(k for k, v in data['species_dict'].items() if v == col['composition']),
                                'efficiency': {'A': col['efficiency'],'b':0,'Ea':0},
                                'note': col['note']
                            })
        # print(colliders)
        # print(colliderNames)
        return colliders

    def _to_builtin(self, obj):
        if isinstance(obj, dict):
            return {self._to_builtin(k): self._to_builtin(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._to_builtin(i) for i in obj]
        elif hasattr(obj, 'as_dict'):
            return self._to_builtin(obj.as_dict())
        elif hasattr(obj, '__dict__'):
            return self._to_builtin(vars(obj))
        elif hasattr(obj, 'tolist'):  # NumPy arrays or similar
            return obj.tolist()
        else:
            return obj
        
    # def validate(self,soln):
    #     for rxn in soln.reactions():
    #         try:
    #             buf = io.StringIO()
    #             test_soln = {
    #                 'species': soln.species(),  # list of ct.Species objects
    #                 'thermo': soln.thermo_model,
    #                 'transport': soln.transport_model,
    #                 'reactions': [rxn],
    #             }
    #             testSoln = ct.Solution(**test_soln)
    #             testSoln.write_yaml(buf)
    #         except Exception as e:
    #             print(f"❌ {rxn.equation} could not be scanned, check the input file for errors.")
    #             print("   Error message:", e)
    #             print(rxn.input_data)


    def _zippedMech(self, data):
        # input_data = gas.input_data
        newReactions = []
        blendRxnNames = [rxn['pes'] for rxn in data['blend']['reactions']]
        # for mech_rxn in data['mech']['reactions']:
        for i, mech_rxn in enumerate(data['mech_obj'].reactions()):
            pDep = False
            # Create the M-collider entry for the pressure-dependent reactions
            if mech_rxn.reaction_type in ['falloff-Troe','pressure-dependent-Arrhenius','Chebyshev','three-body-linear-Burke']:
                
                pDep = True
                if mech_rxn.reaction_type == 'three-body-linear-Burke':
                    d = self._to_builtin(mech_rxn.input_data['colliders'][0]) #use the pdep format given for collider M when rebuilding the reaction
                    d.pop("name")
                else:
                    d = self._to_builtin(mech_rxn.input_data)
                    d.pop("equation")
                    d.pop("efficiencies",None) #only applies to Troe reactions
                d.pop("duplicate", None)
                d.pop("units", None)
                if d.get('Troe') is not None:
                    d['Troe']=dict(d['Troe'])
                if d.get('low-P-rate-constant') is not None:
                    d['low-P-rate-constant']=dict(d['low-P-rate-constant'])
                if d.get('high-P-rate-constant') is not None:
                    d['high-P-rate-constant']=dict(d['high-P-rate-constant'])
                colliderM = {'name': 'M'}
                colliderM.update(dict(d))
            if pDep and (data['mech_pes'][i] in blendRxnNames or data ['allPdep']):
                if data['mech_pes'][i] in blendRxnNames:
                    # rxn is specifically covered either in defaults or user input
                    idx = blendRxnNames.index(data['mech_pes'][i])
                    blend_rxn = data['blend']['reactions'][idx]
                    colliders = self._colliders(data,mech_rxn,blend_rxn=blend_rxn)
                    param_type = "ab initio"
                elif data ['allPdep']:
                    colliders = self._colliders(data,mech_rxn,generic=True)
                    param_type = "generic"
                d = self._to_builtin(mech_rxn.input_data)
                newRxn = {
                    'equation': mech_rxn.equation,
                    **({'duplicate': True} if d.get('duplicate') else {}),
                    **({'units': d['units']} if d.get('units') else {}),
                    'type': 'linear-Burke',
                    'colliders': [colliderM] + colliders
                }
                if 'note' in d and re.fullmatch(r'\n+', d['note']):
                    newRxn['note'] = ''
                yaml_str = yaml.dump(newRxn, sort_keys=False)
                newRxn_obj = ct.Reaction.from_yaml(yaml_str,data['mech_obj'])
                newReactions.append(newRxn_obj)
                print(f"{mech_rxn} {dict(data['mech_pes'][i])} converted to LMR-R with {param_type} parameters")
            else: # just append it as-is
                d = mech_rxn.input_data
                if 'note' in d and re.fullmatch(r'\n+', d['note']):
                    mech_rxn.update_user_data({'note': ''})
                newReactions.append(mech_rxn)
        # output_data = {
        #     'species': data['mech_obj'].species(),  # list of ct.Species objects
        #     'thermo': data['mech_obj'].thermo_model,
        #     'transport': data['mech_obj'].transport_model,
        #     'reactions': newReactions,
        #     'name': 'outputMech'
        # }
        output_data = {
            'thermo': data['mech_obj'].thermo_model,
            'kinetics': data['mech_obj'].kinetics_model,
            'transport': data['mech_obj'].transport_model,
            'species': data['mech_obj'].species(),
            'reactions': newReactions,
            'name': 'outputMech',
        }
        data['output'] = ct.Solution(**output_data)

    def _loadYAML(self, fName):
        with open(fName) as f:
            return yaml.safe_load(f)
    
    def _saveYAML(self, dataSet, fName):
        dataSet.write_yaml(filename=fName,
                units=self.units)
        # Resave it to remove formatting inconsistencies
        dat = self._loadYAML(fName)
        with open(fName, 'w') as outfile:
            yaml.dump(copy.deepcopy(dat), outfile,
                    default_flow_style=None,
                    sort_keys=False)
       